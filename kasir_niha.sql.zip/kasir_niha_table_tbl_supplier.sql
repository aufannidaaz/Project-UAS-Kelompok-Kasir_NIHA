
-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_supplier`
--

DROP TABLE IF EXISTS `tbl_supplier`;
CREATE TABLE `tbl_supplier` (
  `id_supplier` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `telpon` varchar(25) NOT NULL,
  `deskripsi` varchar(256) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id_supplier`, `nama`, `telpon`, `deskripsi`, `alamat`) VALUES
(2, 'PT Swastamita Kasih', '02717574333', 'Distributor Buku', 'Jalan Sudirman'),
(4, 'CV Atma Amerta', '02717574346', 'Distributor Elektronik', 'Jl Sisingamangaraja'),
(10, 'PT Sinar Sosro', '085331997327', 'Distributor Teh', 'Kartasura'),
(11, 'PT Santos Jaya Abadi', '08125665943', 'Distributor Kopi', 'DKI Jakarta');
