
-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE `tbl_customer` (
  `id_customer` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `telepon` varchar(25) NOT NULL,
  `usia` varchar(25) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_customer`
--

INSERT INTO `tbl_customer` (`id_customer`, `nama`, `telepon`, `usia`, `alamat`) VALUES
(3, 'Almira Dzurriya', '0843453843', '14', 'Solobaru'),
(5, 'Karina', '08263478358', '24', 'Seoul'),
(6, 'Gisella', '0896427743', '19', 'Tangerang');
