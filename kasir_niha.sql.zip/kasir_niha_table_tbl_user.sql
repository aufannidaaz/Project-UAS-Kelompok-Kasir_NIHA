
-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `address` varchar(100) NOT NULL,
  `level` int(1) NOT NULL COMMENT '1-administrator 2-supervisor 3-operator',
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `username`, `fullname`, `password`, `address`, `level`, `foto`) VALUES
(2, 'fathimahh', 'DIanaa', '$2y$10$VvVbTVQxFNhOrDx5hHpzr.jSIhEwU7/HBsVSIHP/U9ck.qsrfsWWO', 'bandungg', 2, 'default.png'),
(10, 'lion', 'lioni', '$2y$10$j.1.OD000f9WclFzf9jS7uSFlvyd2/dtytoTZmZ5s5wMbioV1wZSa', 'jambi', 2, 'default.png'),
(11, 'jio', 'jioo', '$2y$10$0BHqgE8gac.rfzB1JysauOHm1HULtXYaOYajjw3Fl7iwd0c/35X4q', 'lombok', 2, 'default.png'),
(13, 'bila', 'Fathimah hana', '$2y$10$xn/ZqfGRAVjKo.YsNLxEEuE6RyIQ.G0uGdCLLEtBjAt29l/W/zXPG', 'solo', 1, 'default.png'),
(14, 'hio', 'hio', '$2y$10$RfdWJbXv5x5hDqLY6LADKO4pihE7bVO9WfocLnzYHV6Nly4RF.9e6', 'solo', 1, 'default.png'),
(15, 'kabag1', 'kabag1', '$2y$10$pb3l5cRYCz/QVqhdv2PTs.stZu3EczyFRyGy4rv0emGQXQN3yHeFm', 'semarang', 2, 'default.png'),
(16, 'kasir', 'Rihana saifa', '$2y$10$B4T0q2nVq2yzlbcbG0bnn.ae051MDT0aN2YuJAaZASNo143XBK7Zy', 'solo', 3, 'default.png'),
(17, 'admin', 'admin', '$2y$10$IbsftffnwjXlCthOFml0COBIvIbi4ZtjXCtiPwI0Y/mPVRoVGstKW', 'solo', 1, 'default.png');
