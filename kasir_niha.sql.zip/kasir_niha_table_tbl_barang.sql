
-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_barang`
--

DROP TABLE IF EXISTS `tbl_barang`;
CREATE TABLE `tbl_barang` (
  `id_barang` varchar(100) NOT NULL,
  `barcode` varchar(20) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `stock_minimal` int(11) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_barang`
--

INSERT INTO `tbl_barang` (`id_barang`, `barcode`, `nama_barang`, `harga_beli`, `harga_jual`, `stock`, `satuan`, `stock_minimal`, `gambar`) VALUES
('BRG-001', '5363829', 'Sirup Marjan', 15000, 20000, 0, 'botol', 10, 'BRG-001.jpeg'),
('BRG-002', '862458', 'Minyak Goreng', 25000, 30000, 0, 'pouch', 15, 'BRG-002.jpeg'),
('BRG-003', '945372', 'Susu Kental Manis', 10000, 13000, 0, 'kaleng', 40, 'BRG-003.jpg'),
('BRG-004', '48785239', 'Kopi Kapal Api', 2000, 2500, 0, 'piece', 50, 'BRG-004.jpg'),
('BRG-005', '3589739', 'Mie Goreng', 3000, 3500, 0, 'piece', 70, 'BRG-005.png');
