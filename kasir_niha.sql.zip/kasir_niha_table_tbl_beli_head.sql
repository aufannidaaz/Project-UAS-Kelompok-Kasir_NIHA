
-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_beli_head`
--

DROP TABLE IF EXISTS `tbl_beli_head`;
CREATE TABLE `tbl_beli_head` (
  `no_beli` varchar(20) NOT NULL,
  `tanggal_beli` date NOT NULL,
  `suplier` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
